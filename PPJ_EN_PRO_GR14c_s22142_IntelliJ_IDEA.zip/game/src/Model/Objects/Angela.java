package Model.Objects;

import Model.Point;

public class Angela extends Point {

//my NpC
    //this class is just needed to set character representation of object and
    // to set it on board with using method from extended class
}
